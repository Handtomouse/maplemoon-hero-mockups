# Source Authority — Locked Reference

The current packaging authority is the bilingual Arabic/English Saudi Moon `CLEAN-SET_10-AUG-2026` folder:

https://drive.google.com/drive/folders/1h0M_Sz3NCbWfTjPfmlV30P52EqCUFzAu

The included `MM_Packaging-Reference_Moons-Pure-Carob_Bilingual_10-AUG-2026_PRINT.pdf` is an unchanged copy of the Pure Carob print PDF from that set. It is included only to show the live placement, colour, scale, and relationship of the supplied icons.

Do not edit, plate, or manufacture from this reference copy. Obtain approved production artwork through MapleMoon's packaging production process.

