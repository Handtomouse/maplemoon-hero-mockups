# MapleMoon Packaging Icon & Brand Asset Kit

Prepared 25 August 2026 for client and external designer use.

## What is included

- 13 distinct, current assets supplied individually as editable SVG vectors.
- Matching transparent PNG files at 2000 × 2000 px.
- A two-page contact sheet for visual identification and usage notes.
- One locked bilingual Saudi Moon packaging PDF as a visual reference only.

Start with `02_REVIEW_PROOFS/MapleMoon_Packaging-Icon_Contact-Sheet_20260825.pdf`, then select individual files from `03_FINAL_PRODUCTION_PENDING`.

## Current source authority

The artwork was checked against the bilingual Arabic/English Saudi Moon clean set dated 10 August 2026. The current packaging source folder is:

https://drive.google.com/drive/folders/1h0M_Sz3NCbWfTjPfmlV30P52EqCUFzAu

The included Pure Carob PDF is locked reference material. Do not edit it or treat it as a production source file.

## Choosing assets

- Use only the ingredient-count badge that matches the SKU: 2, 3, or 4 ingredients.
- The SVG files are the preferred editable artwork for Adobe Illustrator and other vector applications.
- PNG files are transparent placement copies for screen layouts, mockups, and review.
- Do not alter wording, proportions, colour, or claim usage without MapleMoon approval.
- All applications remain subject to final brand, claims, and production approval.

## Exclusions

Working Illustrator masters, superseded packaging, duplicate icon iterations, and unused `_full` variants are intentionally excluded.

